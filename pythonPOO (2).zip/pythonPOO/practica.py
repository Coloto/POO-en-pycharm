#crea una clase llamada Producto
#nombre, unidades y precio
#creas un producto camisa, 10, 9.95 de precio
#muestra el nombre de producto por consola

#crea un método de infoProducto. Muestra el nombre, unidades, precio y inventario valorado (uxp)

#práctica de sobreescritura.
#crea una clase llamada Servicio
#tiene un método llamado consultarDetalle que muestra. el servicio es básico.
#la empresa tiene dos servicios. estándar y premium. Son dos clases que derivan de Servicio
#la clase Estandar y Premium tienen un método llamado consultarDetalle y explican que son
#servicio estándar y premium respectivamente.
#pide por consola un servicio. Elegimos premium y te muestra el resultado de consultarDetalle


class Producto:
    def __init__(self,nombre,unidades,precio):
        self.nombre=nombre
        self.unidades=unidades
        self.precio=precio
    def infoProducto(self):
        print(f'El {self.nombre} son {self.unidades} unidades y cuesta {self.precio}€, en total {self.unidades*self.precio}.')

producto1=Producto('Jamón',4,140)

print(producto1.nombre)
producto1.infoProducto()

class Servicio():
    @staticmethod
    def consultarDetalle():
        print(f'el servicio es básico')
class Estandar(Servicio):
    @staticmethod
    def consultarDetalle():
        print('Estas en el servicio estandar')
class Premium(Servicio):
    @staticmethod
    def consultarDetalle():
        print('Estás en el servicio premium')
servicioP=Premium()

opcion=input('Elije una opción: ')
if opcion=='premium':
    servicioP.consultarDetalle()

